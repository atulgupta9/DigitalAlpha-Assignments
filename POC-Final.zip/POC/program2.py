from rasa_nlu.converters import load_data
from rasa_nlu.config import RasaNLUConfig
from rasa_nlu.model import Trainer
from rasa_core.agent import Agent
from rasa_core.policies.keras_policy import KerasPolicy
from rasa_core.policies.memoization import MemoizationPolicy
from rasa_core.interpreter import RasaNLUInterpreter
from rasa_core.channels.console import ConsoleInputChannel

def create_rasa_nlu_model():
	training_data = load_data('C:\\Users\\user\\Desktop\\POC\\data\\compiledTrainingData.json')
	trainer = Trainer(RasaNLUConfig("C:\\Users\\user\\Desktop\\POC\\nlu_model_config.json"))
	trainer.train(training_data)
	model_directory = trainer.persist('models/nlu/', fixed_model_name="poc")
	return(model_directory)
	

def train_dialogue(domain_file="Domain.yml",
                   model_path="models/dialogue",
                   training_data_file="stories.md"):
    agent = Agent(domain_file,
                  policies=[MemoizationPolicy(),KerasPolicy()])

    agent.train(
            training_data_file,
            max_history=3,
            epochs=400,
            batch_size=10,
            validation_split=0.2
    )

    agent.persist(model_path)    
	

def run_weather_bot(serve_forever=True):
	#model_directory = create_rasa_nlu_model()
	interpreter = RasaNLUInterpreter('./models/nlu/default/poc')
	agent = Agent.load('./models/dialogue', interpreter = interpreter)
	
	if serve_forever:
		agent.handle_channel(ConsoleInputChannel())
		
	return agent

create_rasa_nlu_model()
train_dialogue()
run_weather_bot()
